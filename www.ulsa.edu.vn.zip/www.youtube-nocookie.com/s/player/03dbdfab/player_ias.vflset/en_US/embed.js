(function(g) {
    var window = this;
    'use strict';
    var D7c = function(p) {
            p.mutedAutoplay = !1;
            p.endSeconds = NaN;
            p.limitedPlaybackDurationInSeconds = NaN;
            g.ew(p)
        },
        uup = function() {
            return {
                L: "svg",
                X: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                j: [{
                    L: "path",
                    TB: !0,
                    B: "ytp-svg-fill",
                    X: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        ZJc = function() {
            return {
                L: "svg",
                X: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                j: [{
                    L: "path",
                    X: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    L: "path",
                    X: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    L: "path",
                    X: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    L: "path",
                    X: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    L: "path",
                    X: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    L: "path",
                    X: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        U7r = function(p) {
            g.L.call(this, {
                L: "div",
                B: "ytp-related-on-error-overlay"
            });
            var C = this;
            this.api = p;
            this.W = this.C = 0;
            this.S = new g.Rr(this);
            this.T = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.L({
                L: "h2",
                B: "ytp-related-title",
                Ak: "{{title}}"
            });
            this.previous = new g.L({
                L: "button",
                i_: ["ytp-button", "ytp-previous"],
                X: {
                    "aria-label": "Show previous suggested videos"
                },
                j: [g.fq()]
            });
            this.Z = new g.Bq(function(X) {
                C.suggestions.element.scrollLeft = -X
            });
            this.V = this.scrollPosition = 0;
            this.D = !0;
            this.next = new g.L({
                L: "button",
                i_: ["ytp-button", "ytp-next"],
                X: {
                    "aria-label": "Show more suggested videos"
                },
                j: [g.Oy()]
            });
            g.R(this, this.S);
            p = p.K();
            this.api.G("embeds_web_enable_pause_overlay_rounding") && g.Ed(this.element, "ytp-error-overlay-round-corners");
            this.J = p.S;
            g.R(this, this.title);
            this.title.u_(this.element);
            this.suggestions = new g.L({
                L: "div",
                B: "ytp-suggestions"
            });
            g.R(this, this.suggestions);
            this.suggestions.u_(this.element);
            g.R(this, this.previous);
            this.previous.u_(this.element);
            this.previous.listen("click", this.VQ, this);
            g.R(this, this.Z);
            for (var V = {
                    CQ: 0
                }; V.CQ < 16; V = {
                    CQ: V.CQ
                }, V.CQ++) {
                var N = new g.L({
                    L: "a",
                    B: "ytp-suggestion-link",
                    X: {
                        href: "{{link}}",
                        target: p.Z,
                        "aria-label": "{{aria_label}}"
                    },
                    j: [{
                        L: "div",
                        B: "ytp-suggestion-image",
                        j: [{
                            L: "div",
                            X: {
                                "data-is-live": "{{is_live}}"
                            },
                            B: "ytp-suggestion-duration",
                            Ak: "{{duration}}"
                        }]
                    }, {
                        L: "div",
                        B: "ytp-suggestion-title",
                        X: {
                            title: "{{hover_title}}"
                        },
                        Ak: "{{title}}"
                    }, {
                        L: "div",
                        B: "ytp-suggestion-author",
                        Ak: "{{views_or_author}}"
                    }]
                });
                g.R(this, N);
                N.u_(this.suggestions.element);
                var H = N.rV("ytp-suggestion-link");
                g.K2(H, "transitionDelay", V.CQ / 20 + "s");
                this.S.U(H, "click", function(X) {
                    return function(d) {
                        var a = X.CQ,
                            E = C.suggestionData[a],
                            l = E.sessionData;
                        g.KI(C.api.K()) && C.api.G("web_player_log_click_before_generating_ve_conversion_params") ? (C.api.logClick(C.T[a].element), a = E.a8(), E = {}, g.eQ(C.api, E), a = g.GD(a, E), g.Jh(a, C.api, d)) : g.Ml(d, C.api, C.J, l || void 0) && C.api.Ce(E.videoId, l, E.playlistId)
                    }
                }(V));
                this.T.push(N)
            }
            g.R(this, this.next);
            this.next.u_(this.element);
            this.next.listen("click", this.rL, this);
            this.S.U(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.dV().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        fC1 = function(p, C) {
            if (p.api.K().G("web_player_log_click_before_generating_ve_conversion_params"))
                for (var V = Math.floor(-p.scrollPosition / (p.V + p.C)), N = Math.min(V + p.columns, p.suggestionData.length) - 1; V <= N; V++) p.api.logVisibility(p.T[V].element, C)
        },
        OJ2 = function(p) {
            p.next.element.style.bottom =
                p.W + "px";
            p.previous.element.style.bottom = p.W + "px";
            var C = p.scrollPosition,
                V = p.containerWidth - p.suggestionData.length * (p.V + p.C);
            g.Tz(p.element, "ytp-scroll-min", C >= 0);
            g.Tz(p.element, "ytp-scroll-max", C <= V)
        },
        y81 = function(p) {
            for (var C = 0; C < p.suggestionData.length; C++) {
                var V = p.suggestionData[C],
                    N = p.T[C],
                    H = V.shortViewCount ? V.shortViewCount : V.author,
                    X = V.a8(),
                    d = p.api.K();
                if (g.KI(d) && !d.G("web_player_log_click_before_generating_ve_conversion_params")) {
                    var a = {};
                    g.FE(p.api, "addEmbedsConversionTrackingParams", [a]);
                    X = g.GD(X, a)
                }
                N.element.style.display = "";
                a = N.rV("ytp-suggestion-title");
                g.FV.test(V.title) ? a.dir = "rtl" : g.o28.test(V.title) && (a.dir = "ltr");
                a = N.rV("ytp-suggestion-author");
                g.FV.test(H) ? a.dir = "rtl" : g.o28.test(H) && (a.dir = "ltr");
                N.update({
                    views_or_author: H,
                    duration: V.isLivePlayback ? "Live" : V.lengthSeconds ? g.A7(V.lengthSeconds) : "",
                    link: X,
                    hover_title: V.title,
                    title: V.title,
                    aria_label: V.ariaLabel || null,
                    is_live: V.isLivePlayback
                });
                H = V.TW();
                N.rV("ytp-suggestion-image").style.backgroundImage = H ? "url(" + H + ")" : "";
                d.G("web_player_log_click_before_generating_ve_conversion_params") && (p.api.createServerVe(N.element, N), (V = (V = V.sessionData) && V.itct) && p.api.setTrackingParams(N.element, V))
            }
            for (; C < p.T.length; C++) p.T[C].element.style.display = "none";
            OJ2(p)
        },
        r5 = function(p) {
            g.Gb.call(this, p);
            var C = this;
            this.T = null;
            var V = p.K(),
                N = {
                    target: V.Z
                },
                H = ["ytp-small-redirect"];
            V.V ? H.push("no-link") : (V = g.GM(V), N.href = V, N["aria-label"] = "Visit YouTube to search for more videos");
            var X = new g.L({
                L: "a",
                i_: H,
                X: N,
                j: [{
                    L: "svg",
                    X: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    j: [{
                        L: "path",
                        X: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        L: "path",
                        X: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            X.u_(this.element);
            p.createClientVe(X.element, this, 178053);
            this.U(X.element, "click", function(d) {
                q8F(C, d, X.element)
            });
            g.R(this, X);
            p.K().V || (this.T = new U7r(p), this.T.u_(this.element), g.R(this, this.T));
            this.U(p, "videodatachange", function() {
                C.show()
            });
            this.resize(this.api.dV().getPlayerSize())
        },
        q8F = function(p, C, V) {
            C.preventDefault();
            p.api.logClick(V);
            C = V.getAttribute("href");
            V = {};
            g.FE(p.api, "addEmbedsConversionTrackingParams", [V]);
            C = g.k5(V) ? C : g.GD(C, V);
            g.gV(window, C)
        },
        ICG = function(p, C) {
            p.rV("ytp-error-content").style.paddingTop = "0px";
            var V = p.rV("ytp-error-content"),
                N = V.clientHeight;
            p.T && p.T.resize(C, C.height - N);
            V.style.paddingTop = (C.height - (p.T ? p.T.element.clientHeight : 0)) / 2 - N / 2 + "px"
        },
        o7G = function(p, C) {
            var V = p.api.K(),
                N;
            C.reason && (bJ8(C.reason) ? N = g.ZU(C.reason) : N = g.pZ(g.uq(C.reason)), p.Jc(N, "content"));
            var H;
            C.subreason && (bJ8(C.subreason) ? H = g.ZU(C.subreason) : H = g.pZ(g.uq(C.subreason)), p.Jc(H, "subreason"));
            if (C.proceedButton && C.proceedButton.buttonRenderer) {
                N = p.rV("ytp-error-content-wrap-subreason");
                C = C.proceedButton.buttonRenderer;
                var X = g.iK("A");
                if (C.text && C.text.simpleText && (H = C.text.simpleText, X.textContent = H, !A8y(N, H) && (!V.V || V.embedsErrorLinks))) {
                    var d;
                    V = (d = g.n(C == null ? void 0 : C.navigationEndpoint, g.$0)) == null ?
                        void 0 : d.url;
                    var a;
                    d = (a = g.n(C == null ? void 0 : C.navigationEndpoint, g.$0)) == null ? void 0 : a.target;
                    V && (X.setAttribute("href", V), p.api.createClientVe(X, p, 178424), p.U(X, "click", function(E) {
                        q8F(p, E, X)
                    }));
                    d && X.setAttribute("target", d);
                    a = g.iK("DIV");
                    a.appendChild(X);
                    N.appendChild(a)
                }
            }
        },
        bJ8 = function(p) {
            if (p.runs)
                for (var C = 0; C < p.runs.length; C++)
                    if (p.runs[C].navigationEndpoint) return !0;
            return !1
        },
        A8y = function(p, C) {
            p = g.Gh("A", p);
            for (var V = 0; V < p.length; V++)
                if (p[V].textContent === C) return !0;
            return !1
        },
        kDc = function(p, C) {
            g.L.call(this, {
                L: "a",
                i_: ["ytp-impression-link"],
                X: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                j: [{
                    L: "div",
                    B: "ytp-impression-link-content",
                    X: {
                        "aria-hidden": "true"
                    },
                    j: [{
                        L: "div",
                        B: "ytp-impression-link-text",
                        Ak: "Watch on"
                    }, {
                        L: "div",
                        B: "ytp-impression-link-logo",
                        Ak: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = p;
            this.T = C;
            this.updateValue("target", p.K().Z);
            this.U(p, "videodatachange", this.onVideoDataChange);
            this.U(this.api, "presentingplayerstatechange", this.wi);
            this.U(this.api, "videoplayerreset", this.dX);
            this.U(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.dX()
        },
        x70 = function(p) {
            var C = {};
            g.FE(p.api, "addEmbedsConversionTrackingParams", [C]);
            p = p.api.getVideoUrl();
            return p = g.GD(p, C)
        },
        BM = function(p) {
            g.L.call(this, {
                L: "div",
                i_: ["ytp-mobile-a11y-hidden-seek-button"],
                j: [{
                    L: "button",
                    i_: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    X: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    L: "button",
                    i_: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    X: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = p;
            this.T = this.rV("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.rV("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.T, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.U(this.api, "presentingplayerstatechange", this.wi);
            this.U(this.T, "click", this.C);
            this.U(this.forwardButton, "click", this.V);
            this.wi()
        },
        GL = function(p) {
            g.L.call(this, {
                L: "div",
                B: "ytp-muted-autoplay-endscreen-overlay",
                j: [{
                    L: "div",
                    B: "ytp-muted-autoplay-end-panel",
                    j: [{
                        L: "button",
                        i_: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        Ak: "{{text}}"
                    }]
                }]
            });
            this.api = p;
            this.S = this.rV("ytp-muted-autoplay-end-panel");
            this.C = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.U(this.api, "presentingplayerstatechange", this.V);
            this.U(p, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        pC = function(p) {
            var C = p.K();
            g.L.call(this, {
                L: "a",
                i_: ["ytp-watermark", "yt-uix-sessionlink"],
                X: {
                    target: C.Z,
                    href: "{{url}}",
                    "aria-label": g.Ks("Watch on $WEBSITE", {
                        WEBSITE: g.zM(C)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                Ak: "{{logoSvg}}"
            });
            this.api = p;
            this.T = null;
            this.C = !1;
            this.state = p.getPlayerStateObject();
            this.U(p, "videodatachange", this.onVideoDataChange);
            this.U(p, "presentingplayerstatechange", this.onStateChange);
            this.U(p, "appresize", this.OR);
            this.onVideoDataChange();
            this.UZ(this.state);
            this.OR(p.dV().getPlayerSize())
        },
        Y82 = function(p) {
            var C = p.api.getVideoData(),
                V = p.api.K();
            V = V.FO && !g.r(p.state, 2) && !g.lx(p.api.getVideoData(1)) && !(V.G("embeds_enable_emc3ds_woyt_counterfactual") && p.api.getPlayerStateObject().isCued());
            C.mutedAutoplay || p.jb(V);
            p.api.logVisibility(p.element, V)
        },
        n7r = function(p) {
            g.L.call(this, {
                L: "div",
                B: "ytp-muted-autoplay-overlay",
                j: [{
                    L: "div",
                    B: "ytp-muted-autoplay-bottom-buttons",
                    j: [{
                        L: "button",
                        i_: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        X: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        j: [{
                            L: "div",
                            i_: ["ytp-muted-autoplay-equalizer-icon"],
                            j: [{
                                L: "svg",
                                X: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                j: [{
                                    L: "g",
                                    X: {
                                        fill: "#fff"
                                    },
                                    j: [{
                                            L: "rect",
                                            B: "ytp-equalizer-bar-left",
                                            X: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            L: "rect",
                                            B: "ytp-equalizer-bar-middle",
                                            X: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            L: "rect",
                                            B: "ytp-equalizer-bar-right",
                                            X: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var C = this;
            this.api = p;
            this.bottomButtons = this.rV("ytp-muted-autoplay-bottom-buttons");
            this.V = new g.N8(this.jk, 4E3, this);
            this.C = !1;
            p.createClientVe(this.element, this, 39306);
            this.U(p, "presentingplayerstatechange", this.En);
            this.U(p, "onMutedAutoplayStarts", function() {
                zNp(C);
                C.En();
                RNp(C);
                C.C = !1
            });
            this.U(p, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.U(p, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            p.isMutedByEmbedsMutedAutoplay() && (zNp(this), this.En(), RNp(this));
            g.R(this, this.V)
        },
        RNp = function(p) {
            p.C4 && p.T && (p.T.show(), p.V.start())
        },
        zNp = function(p) {
            p.watermark || (p.watermark = new pC(p.api), g.R(p, p.watermark), p.watermark.u_(p.bottomButtons, 0), g.Tz(p.watermark.element, "ytp-muted-autoplay-watermark", !0), p.T = new g.a0(p.watermark, 0, !0, 100), g.R(p,
                p.T))
        },
        CC = function(p) {
            g.L.call(this, {
                L: "div",
                B: "ytp-pause-overlay",
                X: {
                    tabIndex: "-1"
                }
            });
            var C = this;
            this.api = p;
            this.V = new g.Rr(this);
            this.S = new g.a0(this, 1E3, !1, 100, function() {
                C.T.C = !1
            }, function() {
                C.T.C = !0
            });
            this.C = !1;
            this.expandButton = new g.L({
                L: "button",
                i_: ["ytp-button", "ytp-expand"],
                Ak: this.api.isEmbedsShortsMode() ? "More shorts" : "More videos"
            });
            p.K().controlsType === "0" && g.Ed(p.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.api.G("embeds_web_enable_pause_overlay_rounding") && g.Ed(this.element, "ytp-pause-overlay-round-corners");
            g.R(this, this.V);
            g.R(this, this.S);
            var V = new g.L({
                L: "button",
                i_: ["ytp-button", "ytp-collapse"],
                X: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "Hide more shorts" : "Hide more videos"
                },
                j: [{
                    L: "div",
                    B: "ytp-collapse-icon",
                    j: [g.Y0()]
                }]
            });
            g.R(this, V);
            V.u_(this.element);
            V.listen("click", this.W, this);
            g.R(this, this.expandButton);
            this.expandButton.u_(this.element);
            this.expandButton.listen("click", this.D, this);
            this.T = new g.GS(p);
            g.R(this, this.T);
            this.T.C = !1;
            this.T.u_(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.V.U(this.api, "presentingplayerstatechange", this.Pr);
            this.V.U(this.api, "videodatachange",
                this.Pr);
            this.hide()
        },
        jN = function(p) {
            g.L.call(this, {
                L: "div",
                i_: ["ytp-player-content", "ytp-iv-player-content"],
                j: [{
                    L: "div",
                    B: "ytp-countdown-timer",
                    j: [{
                        L: "svg",
                        X: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        j: [{
                            L: "circle",
                            B: "ytp-svg-countdown-timer-ring",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            L: "circle",
                            B: "ytp-svg-countdown-timer-background",
                            X: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        L: "span",
                        B: "ytp-countdown-timer-time",
                        Ak: "{{duration}}"
                    }]
                }]
            });
            this.api = p;
            this.D = this.rV("ytp-svg-countdown-timer-ring");
            this.T = null;
            this.S = this.V = 0;
            this.C = !1;
            this.W = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        Pmy = function(p) {
            p.T || (p.V = 5E3, p.S = (0, g.Ip)(), p.T = new g.V2(function() {
                eN0(p)
            }, null), eN0(p))
        },
        eN0 = function(p) {
            if (!p.C) {
                var C = Math.min((0, g.Ip)() - p.S, p.V);
                var V = p.V - C;
                C = p.V === 0 ? 0 : Math.max(V / p.V, 0);
                V = Math.round(V / 1E3);
                p.D.setAttribute("stroke-dashoffset", "" + -211 * (C + 1));
                p.updateValue("duration", V);
                C <= 0 && p.T ? Va(p) : p.T && p.T.start()
            }
        },
        Va = function(p) {
            p.T && (p.T.dispose(), p.T = null, p.C = !1)
        },
        $7c = function(p) {
            g.IT.call(this, p);
            this.N = p;
            this.T = new g.Rr(this);
            this.C = null;
            this.D = !1;
            this.countdownTimer = null;
            this.Z = !1;
            wXE(this);
            g.R(this, this.T);
            this.load()
        },
        g7P = function(p) {
            var C = g.QGv(p.N);
            C !== p.Z && (p.Z = C, p.W && (p.W.dispose(), p.W = null), p.V && (p.V.dispose(), p.V = null), p.S && (p.S.dispose(), p.S = null), p.C && (p.C.stop(), p.C.dispose(), p.C = null), C && (C = g.Zg(p.N), p.N.isEmbedsShortsMode() && (p.S = new g.L({
                L: "div",
                B: "ytp-pause-overlay-backdrop",
                X: {
                    tabIndex: "-1"
                }
            }), g.R(p, p.S), g.LT(p.N, p.S.element, 4), p.C = new g.a0(p.S, 1E3, !1, 100), g.R(p, p.C), p.S.hide()), p.W = new g.L({
                L: "div",
                B: "ytp-pause-overlay-container",
                X: {
                    tabIndex: "-1"
                }
            }), g.R(p, p.W), p.V = new CC(p.N, C), g.R(p, p.V), p.V.u_(p.W.element), g.LT(p.N, p.W.element,
                4), Lor(p, p.N.getPlayerStateObject())))
        },
        Lor = function(p, C) {
            p.C && (!g.r(C, 4) && !g.r(C, 2) || g.r(C, 1024) ? p.C.hide() : p.C.show())
        },
        wXE = function(p) {
            var C = p.N;
            p = !!C.isEmbedsShortsMode();
            g.Tz(C.getRootNode(), "ytp-shorts-mode", p);
            if (C = C.getVideoData()) C.YY = p
        },
        N0 = function(p, C) {
            var V = p.N.K();
            p = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: p.N.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : p.N.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.ZHV(p.N.K().loaderUrl),
                eventType: C,
                youtubeHost: g.LJ(p.N.K().Vn) || ""
            };
            p.embeddedPlayerMode = V.Sa;
            g.t1("embedsAdEvent", p)
        };
    g.m(U7r, g.L);
    g.h = U7r.prototype;
    g.h.hide = function() {
        this.D = !0;
        g.L.prototype.hide.call(this);
        fC1(this, !1)
    };
    g.h.show = function() {
        this.D = !1;
        g.L.prototype.show.call(this);
        fC1(this, !0)
    };
    g.h.isHidden = function() {
        return this.D
    };
    g.h.rL = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.h.VQ = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.h.resize = function(p, C) {
        var V = this.api.K(),
            N = 16 / 9,
            H = p.width >= 650,
            X = p.width < 480 || p.height < 290,
            d = Math.min(this.suggestionData.length, this.T.length);
        if (Math.min(p.width, p.height) <= 150 || d === 0 || !V.QZ) this.hide();
        else {
            var a;
            if (H) {
                var E = a = 28;
                this.C = 16
            } else this.C = E = a = 8;
            if (X) {
                var l = 6;
                H = 14;
                var t = 12;
                X = 24;
                V = 12
            } else l = 8, H = 18, t = 16, X = 36, V = 16;
            p = p.width - (48 + a + E);
            a = Math.ceil(p / 150);
            a = Math.min(3, a);
            E = p / a - this.C;
            var c = Math.floor(E / N);
            C && c + 100 > C && E > 50 && (c = Math.max(C, 50 / N), a = Math.ceil(p / (N * (c - 100) + this.C)), E = p / a - this.C,
                c = Math.floor(E / N));
            E < 50 || g.nT(this.api) ? this.hide() : this.show();
            for (C = 0; C < d; C++) {
                N = this.T[C];
                var T = N.rV("ytp-suggestion-image");
                T.style.width = E + "px";
                T.style.height = c + "px";
                N.rV("ytp-suggestion-title").style.width = E + "px";
                N.rV("ytp-suggestion-author").style.width = E + "px";
                N = N.rV("ytp-suggestion-duration");
                N.style.display = N && E < 100 ? "none" : ""
            }
            d = H + l + t + 4;
            this.W = d + V + (c - X) / 2;
            this.suggestions.element.style.height = c + d + "px";
            this.V = E;
            this.containerWidth = p;
            this.columns = a;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            OJ2(this)
        }
    };
    g.h.onVideoDataChange = function() {
        var p = this.api.getVideoData(),
            C = this.api.K();
        this.J = p.UV ? !1 : C.S;
        p.suggestions ? this.suggestionData = g.JT(p.suggestions, function(V) {
            return V && !V.playlistId
        }) : this.suggestionData.length = 0;
        y81(this);
        p.UV ? this.title.update({
            title: g.Ks("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: p.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.h.scrollTo = function(p) {
        p = g.J9(p, this.containerWidth - this.suggestionData.length * (this.V + this.C), 0);
        this.Z.start(this.scrollPosition, p, 1E3);
        this.scrollPosition = p;
        OJ2(this);
        fC1(this, !0)
    };
    g.m(r5, g.Gb);
    r5.prototype.show = function() {
        g.Gb.prototype.show.call(this);
        ICG(this, this.api.dV().getPlayerSize())
    };
    r5.prototype.resize = function(p) {
        g.Gb.prototype.resize.call(this, p);
        this.T && (ICG(this, p), g.Tz(this.element, "related-on-error-overlay-visible", !this.T.isHidden()))
    };
    r5.prototype.C = function(p) {
        g.Gb.prototype.C.call(this, p);
        var C = this.api.getVideoData();
        if (C.Up || C.playerErrorMessageRenderer)(p = C.Up) ? o7G(this, p) : C.playerErrorMessageRenderer && o7G(this, C.playerErrorMessageRenderer);
        else {
            var V;
            p.Ck && (C.QR ? bJ8(C.QR) ? V = g.ZU(C.QR) : V = g.pZ(g.uq(C.QR)) : V = g.pZ(p.Ck), this.Jc(V, "subreason"))
        }
    };
    g.m(kDc, g.L);
    g.h = kDc.prototype;
    g.h.onVideoDataChange = function() {
        var p = this.api.getVideoData(),
            C = uup(),
            V = 96714;
        g.t_(p) ? (C = ZJc(), V = 216165, g.Ed(this.element, "ytp-music-impression-link")) : g.tk(this.element, "ytp-music-impression-link");
        this.api.K().G("embeds_enable_emc3ds_woyt_counterfactual") && g.Ed(this.element, "ytp-woyt-emc3ds-cf");
        this.updateValue("logoSvg", C);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, V)
    };
    g.h.wi = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.h.dX = function() {
        var p = this.api.getVideoData(),
            C = this.api.K(),
            V = this.api.getVideoData().UV,
            N = C.FO && !C.G("embeds_enable_emc3ds_woyt_counterfactual"),
            H = !C.QZ,
            X = this.T.OE() && !C.G("embeds_enable_emc3ds_woyt_counterfactual");
        C = C.V;
        N || X || V || H || C || this.api.isEmbedsShortsMode() || !p.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (p = x70(this), this.updateValue("url", p), this.show())
    };
    g.h.onClick = function(p) {
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var C = x70(this);
        g.Jh(C, this.api, p);
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.h.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.L.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.m(BM, g.L);
    BM.prototype.wi = function() {
        var p = this.api.getPlayerStateObject();
        !this.api.CO() || g.r(p, 2) && g.Yj(this.api) || g.r(p, 64) ? (this.api.logVisibility(this.T, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.T, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    BM.prototype.C = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.T)
    };
    BM.prototype.V = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.m(GL, g.L);
    GL.prototype.V = function() {
        var p = this.api.getPlayerStateObject(),
            C = this.api.getVideoData();
        this.api.K().G("embeds_enable_muted_autoplay_shorts_endscreen_fix") && g.Tz(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !C.mutedAutoplay || this.api.G("embeds_enable_full_length_inline_muted_autoplay") && C.limitedPlaybackDurationInSeconds === 0 && C.endSeconds === 0 || (g.r(p, 2) && !this.C4 ? (this.show(), this.T || (this.T = new g.rM(this.api), g.R(this, this.T), this.T.u_(this.S, 0), this.T.show()), p = this.api.getVideoData(), this.updateValue("text",
            p.fI), g.Tz(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element, this.C4), this.api.Ba("onMutedAutoplayEnds")) : this.hide())
    };
    GL.prototype.onClick = function() {
        if (!this.C) {
            this.T && (this.T.CS(), this.T = null);
            g.Tz(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var p = this.api.getVideoData(),
                C = this.api.getCurrentTime();
            D7c(p);
            this.api.loadVideoById(p.videoId, C);
            this.api.tS();
            this.api.logClick(this.element);
            this.hide();
            this.C = !0
        }
    };
    GL.prototype.onMutedAutoplayStarts = function() {
        this.C = !1;
        this.T && (this.T.CS(), this.T = null)
    };
    g.m(pC, g.L);
    g.h = pC.prototype;
    g.h.onStateChange = function(p) {
        this.UZ(p.state)
    };
    g.h.UZ = function(p) {
        this.state !== p && (this.state = p);
        Y82(this)
    };
    g.h.onVideoDataChange = function() {
        var p = this.api.K();
        p.V && g.Ed(this.element, "ytp-no-hover");
        var C = this.api.getVideoData();
        C.videoId && !p.V ? (p = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", p), this.T || (this.T = this.listen("click", this.onClick))) : this.T && (this.updateValue("url", null), this.rY(this.T), this.T = null);
        p = uup();
        var V = 76758;
        g.t_(C) && (p = ZJc(), V = 216164);
        this.updateValue("logoSvg", p);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            V);
        Y82(this)
    };
    g.h.onClick = function(p) {
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var C = this.api.getVideoUrl(!g.o0(p), !1, !0, !0);
        if (this.api.G("web_player_log_click_before_generating_ve_conversion_params")) {
            var V = {};
            g.FE(this.api, "addEmbedsConversionTrackingParams", [V]);
            C = g.GD(C, V)
        }
        g.Jh(C, this.api, p);
        this.api.G("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.h.OR = function(p) {
        if ((p = p.width < 480) && !this.C || !p && this.C) {
            var C = new g.L(uup()),
                V = this.rV("ytp-watermark");
            g.Tz(V, "ytp-watermark-small", p);
            g.aN(V);
            C.u_(V);
            this.C = p
        }
    };
    g.m(n7r, g.L);
    g.h = n7r.prototype;
    g.h.En = function() {
        var p = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.r(p, 2) ? this.hide() : this.C4 || (g.L.prototype.show.call(this), this.api.logVisibility(this.element, this.C4))
    };
    g.h.jk = function() {
        this.T && this.T.hide()
    };
    g.h.onAutoplayBlocked = function() {
        this.hide();
        D7c(this.api.getVideoData())
    };
    g.h.onClick = function() {
        if (!this.C) {
            g.Tz(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var p = this.api.getVideoData(),
                C = this.api.getCurrentTime();
            D7c(p);
            this.api.loadVideoById(p.videoId, C);
            this.api.tS();
            this.api.logClick(this.element);
            this.api.Ba("onMutedAutoplayEnds");
            this.C = !0
        }
    };
    g.h.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.CS(), this.watermark = null)
    };
    g.m(CC, g.L);
    CC.prototype.hide = function() {
        g.tk(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.L.prototype.hide.call(this)
    };
    CC.prototype.W = function() {
        this.C = !0;
        g.tk(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    CC.prototype.D = function() {
        this.C = !1;
        g.Ed(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    CC.prototype.Pr = function() {
        var p = this.api.getPlayerStateObject();
        g.r(p, 1) || g.r(p, 16) || g.r(p, 32) || (!g.r(p, 4) || g.r(p, 2) || g.r(p, 1024) ? (this.C || this.api.logVisibility(this.element, !1), this.S.hide()) : this.T.hasSuggestions() && (this.C || (g.Ed(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.pM(this.T), this.T.show(), this.api.logVisibility(this.element, !0)), this.S.show()))
    };
    g.m(jN, g.L);
    jN.prototype.show = function() {
        g.L.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    jN.prototype.CS = function() {
        Va(this);
        g.L.prototype.CS.call(this)
    };
    g.m($7c, g.IT);
    g.h = $7c.prototype;
    g.h.P_ = function() {
        return !1
    };
    g.h.create = function() {
        var p = this.N.K(),
            C = g.Zg(this.N),
            V, N = (V = this.N.getVideoData()) == null ? void 0 : V.clientPlaybackNonce;
        N && g.HH({
            clientPlaybackNonce: N
        });
        p.UY && !p.disableOrganicUi && g7P(this);
        var H;
        this.N.G("embeds_enable_emc3ds_muted_autoplay") && ((H = p.getWebPlayerContextConfig()) == null ? 0 : H.embedsEnableEmc3ds) || (this.J = new n7r(this.N), g.R(this, this.J), g.LT(this.N, this.J.element, 4), this.b_ = new GL(this.N), g.R(this, this.b_), g.LT(this.N, this.b_.element, 4));
        p.FO && (this.watermark = new pC(this.N), g.R(this, this.watermark),
            g.LT(this.N, this.watermark.element, 8));
        C && !p.disableOrganicUi && (this.Y = new kDc(this.N, C), g.R(this, this.Y), g.LT(this.N, this.Y.element, 8), this.N.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.Y.hide()));
        p.C && !p.disableOrganicUi && (this.a$ = new BM(this.N), g.R(this, this.a$), g.LT(this.N, this.a$.element, 4));
        this.T.U(this.N, "appresize", this.OR);
        this.T.U(this.N, "presentingplayerstatechange", this.wi);
        this.T.U(this.N, "videodatachange", this.onVideoDataChange);
        this.T.U(this.N, "videoplayerreset",
            this.onReset);
        this.T.U(this.N, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
        this.T.U(this.N, "onAdStart", this.onAdStart);
        this.T.U(this.N, "onAdComplete", this.onAdComplete);
        this.T.U(this.N, "onAdSkip", this.onAdSkip);
        this.T.U(this.N, "onAdStateChange", this.onAdStateChange);
        if (this.D = g.cw(g.Ig(p))) this.countdownTimer = new jN(this.N), g.R(this, this.countdownTimer), g.LT(this.N, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.T.U(this.N, g.Ez("embeds"), this.onCueRangeEnter), this.T.U(this.N,
            g.lG("embeds"), this.onCueRangeExit);
        this.aN(this.N.getPlayerStateObject());
        this.player.hp("embed");
        var X, d;
        ((X = this.N.K().getWebPlayerContextConfig()) == null ? 0 : (d = X.embedsHostFlags) == null ? 0 : d.allowOverridingVisitorDataPlayerVars) && (p = g.pO("IDENTITY_MEMENTO")) && this.N.v1("onMementoChange", p)
    };
    g.h.onCueRangeEnter = function(p) {
        p.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), Pmy(this.countdownTimer))
    };
    g.h.onCueRangeExit = function(p) {
        p.getId() === "countdown timer" && this.countdownTimer && (Va(this.countdownTimer), this.countdownTimer.hide())
    };
    g.h.OR = function() {
        var p = this.N.dV().getPlayerSize();
        this.mS && this.mS.resize(p)
    };
    g.h.onReset = function() {
        wXE(this)
    };
    g.h.wi = function(p) {
        this.aN(p.state)
    };
    g.h.aN = function(p) {
        g.r(p, 128) ? (this.mS || (this.mS = new r5(this.N), g.R(this, this.mS), g.LT(this.N, this.mS.element, 4)), this.mS.C(p.UE), this.mS.show(), g.Ed(this.N.getRootNode(), "ytp-embed-error")) : this.mS && (this.mS.dispose(), this.mS = null, g.tk(this.N.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.T)
            if (g.r(p, 64)) this.countdownTimer.hide(), Va(this.countdownTimer);
            else if (p.isPaused()) {
            var C = this.countdownTimer;
            C.C || (C.C = !0, C.W = (0, g.Ip)())
        } else p.isPlaying() && this.countdownTimer.C &&
            (C = this.countdownTimer, C.C && (C.S += (0, g.Ip)() - C.W, C.C = !1, eN0(C)));
        Lor(this, p)
    };
    g.h.onMutedAutoplayStarts = function() {
        this.N.getVideoData().mutedAutoplay && this.J && g.Tz(this.N.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.h.onVideoDataChange = function(p, C) {
        var V = this.w1 !== C.videoId;
        p = !V && p === "dataloaded";
        var N = {
            isShortsModeEnabled: !!this.N.isEmbedsShortsMode()
        };
        g.t1("embedsVideoDataDidChange", {
            clientPlaybackNonce: C.clientPlaybackNonce,
            isReload: p,
            runtimeEnabledFeatures: N
        });
        V && (this.w1 = C.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.D && (this.N.qt("embeds"), C.isAd() || C.limitedPlaybackDurationInSeconds < 5 || g.nT(this.N) || (C = Math.max((C.startSeconds + C.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), C = new g.sz(C, C + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.N.d7([C]))), this.N.K().UY && !this.N.K().disableOrganicUi && (wXE(this), g7P(this)));
        this.N.K().V && this.V && this.V.detach()
    };
    g.h.onAdStart = function() {
        N0(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.h.onAdComplete = function() {
        N0(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.h.onAdSkip = function() {
        N0(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.h.onAdStateChange = function(p) {
        p === 2 && N0(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.qA("embed", $7c);
})(_yt_player);